from core.libs.exceptions import FyleError


def test_fyle_error():
    error = FyleError(404, 'Not Found')
    assert error.status_code == 404
    assert error.message == 'Not Found'


def test_fyle_error_to_dict():
    error = FyleError(404, 'Not Found')
    error_dict = error.to_dict()
    assert isinstance(error_dict, dict)
    assert error_dict['message'] == 'Not Found'

def test_negative_status_code_initialization():
    error = FyleError(-404, 'Not Found')
    assert error.status_code == -404
    assert error.message == 'Not Found'

def test_fyle_error_to_dict_keys():
    error = FyleError(404, 'Not Found')
    error_dict = error.to_dict()
    assert isinstance(error_dict, dict)
    assert 'status_code' in error_dict
    assert 'message' in error_dict

def test_fyle_error_to_dict_status_code():
    error = FyleError(404, 'Not Found')
    error_dict = error.to_dict()
    assert isinstance(error_dict, dict)
    assert error_dict['status_code'] == 404